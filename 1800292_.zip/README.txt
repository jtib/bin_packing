# INF4705_TP2
Optimisation du remplissage de m boîtes de capacité c par n objets de volume variable

-p pour voir le contenu des boîtes
-f [nom fichier] pour l’exemplaire

g++ -std=c++11 -o [executable] [code] pour la compilation

Sites utilisés : cplusplus.com
